starter - 197

1 blog
30 reviews


pro - 297

3 blogs
100 reviews

Premium - 1997

unlimited blogs
unlimited reviews
bulk mode reviews (can upload via spreadsheet)
Weekly calls
Courses







Feature Matrix - Final

  | Feature          | Starter R$197 | Pro R$297     | Premium R$1,997/yr |
  |------------------|---------------|---------------|--------------------|
  | WordPress Blogs  | 1             | 3             | Unlimited          |
  | AI Reviews/month | 30            | 100           | Unlimited          |
  | Bulk Upload      | ❌             | ❌             | ✅ Spreadsheet      |
  | Review Generator | ✅             | ✅             | ✅                  |
  | Content Calendar | Basic         | ✅ Advanced    | ✅ Advanced         |
  | Analytics        | Basic         | Advanced      | Enterprise         |
  | Keyword Research | 10/month      | 50/month      | Unlimited          |
  | Amazon Tools     | Basic         | ✅ All         | ✅ All + API        |
  | Courses          | ❌             | ❌             | ✅ All included     |
  | Support          | Email         | Priority      | VIP 1-on-1         |
  | Training         | ❌             | Monthly group | Weekly 1-on-1      |